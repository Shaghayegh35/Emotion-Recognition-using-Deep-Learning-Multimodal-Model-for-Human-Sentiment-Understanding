Facial Recognition Models:
This repository contains implementations of four Convolutional Neural Network (CNN) models for facial recognition tasks. Each model utilizes a different pre-trained architecture to extract features from facial images.
Model 1: VGG19
Description: Model_1 uses the VGG19 architecture as a pre-trained backbone for facial recognition. VGG19 is known for its deep architecture and excellent performance on image classification tasks.
Model 2: ResNet50
Description: Model_2 is based on the ResNet50 architecture, which is known for its residual blocks. ResNet50 excels at capturing intricate features in images, making it suitable for facial recognition tasks.
Model 3: VGG16
Description: Model_3 utilizes the VGG16 architecture, a predecessor to VGG19. VGG16 is known for its simplicity and effectiveness in image recognition tasks.
Model 4: MobileNet V2
Description: Model_4 employs the MobileNet V2 architecture, designed for efficiency and speed. MobileNet V2 is particularly useful for real-time applications with limited computational resources.